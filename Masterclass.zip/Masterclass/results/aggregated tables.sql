use masterclass;

select count(*) from Data;

select * from Data 
where timestamp like ('%23::%');

#3[A]
create temporary table if not exists temp AS (select timestamp
	,userid
    ,platform
    ,course_id
    ,chapter_id
    ,CASE 
		WHEN HOUR(timestamp)>='00' AND HOUR(timestamp)<='12' THEN 'Morning'
		WHEN HOUR(timestamp)>'12' AND HOUR(timestamp)<='17' THEN 'Afternoon'
        WHEN HOUR(timestamp)>'17' AND HOUR(timestamp)<'24' THEN 'Evening'
	 END as part_day
    
    from Data);
    
create table if not exists masterclass.users_part_day_platform AS (select part_day,platform,count(*) as count_users
from temp
group by part_day,platform);

select * from masterclass.users_part_day_platform;

#3[B]
CREATE TABLE IF NOT EXISTS masterclass.most_viewed_courses AS (select t.part_day,t.course_id,t.most_viewed_course from
(select part_day,course_id,count(*) as most_viewed_course
		,rank() OVER (partition by part_day order by count(*) desc) AS rn
 from temp
group by part_day,course_id)t
where rn=1);

select * from masterclass.most_viewed_courses;

#3[C]
CREATE TABLE IF NOT EXISTS masterclass.most_viewed_chapters AS (select t.part_day,t.chapter_id,t.most_viewed_chapters from
(select part_day,chapter_id,count(*) as most_viewed_chapters
		,rank() OVER (partition by part_day order by count(*) desc) AS rn
 from temp
group by part_day,chapter_id)t
where rn=1);

select * from masterclass.most_viewed_chapters;
 