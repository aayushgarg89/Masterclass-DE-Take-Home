import pandas as pd
import mysql.connector as msql
from mysql.connector import Error

#data=pd.read_csv('C:\\Users\\aayus\\Documents\\Masterclass\\Interview_exercise_Data_Engineering\\Interview_exercise_Data_Engineering\\data.csv'
#                 ,index_col=False,delimiter=',')
#print(data.head())

def connect_to_mysql():
    try:
        conn = msql.connect(host='localhost', user='root',password='infy@123')
        if conn.is_connected():
            cursor = conn.cursor()
            cursor.execute('DROP DATABASE IF EXISTS masterclass;')
            cursor.execute('CREATE DATABASE masterclass;')
            print('Database is created')
    except Error as e:
        print('Error while connecting to MySQL', e)


def import_csv_into_mysql(data):
    try:
        conn=msql.connect(host='localhost',database='masterclass',user='root',password='infy@123')
        if conn.is_connected():
            cursor=conn.cursor()
            cursor.execute('DROP TABLE IF EXISTS Data;')
            print('Creating table...')
            cursor.execute('CREATE TABLE Data(timestamp datetime,userid bigint,platform nvarchar(100),course_id int,chapter_id int)')
            print('table is created')

            for i,row in data.iterrows():
                sql= 'INSERT INTO masterclass.Data VALUES (%s,%s,%s,%s,%s)'
                cursor.execute(sql,tuple(row))
                print('record inserted')
                conn.commit()

    except Error as e:
            print("Error while connecting to MySQL", e)


def users_part_day_platform():
        try:
            conn=msql.connect(host='localhost',database='masterclass',user='root',password='infy@123')
            if conn.is_connected():
                cursor=conn.cursor()
                cursor.execute('''create temporary table if not exists temp AS (select timestamp
                                                                                        ,userid
                                                                                        ,platform
                                                                                        ,course_id
                                                                                        ,chapter_id
                                                                                        ,CASE 
                                                                                            WHEN HOUR(timestamp)>='00' AND HOUR(timestamp)<='12' THEN 'Morning'
                                                                                            WHEN HOUR(timestamp)>'12' AND HOUR(timestamp)<='17' THEN 'Afternoon'
                                                                                            WHEN HOUR(timestamp)>'17' AND HOUR(timestamp)<'24' THEN 'Evening'
                                                                                         END as part_day
        
                                                                                    from Data);'''
                               )
                print('temporary temp table created')
                cursor.execute('''create table if not exists masterclass.users_part_day_platform AS (select part_day,platform,count(*) as count_users
                                                                                                     from temp
                                                                                                        group by part_day,platform);'''
                               )
                print('masterclass.users_part_day_platform table created')
                cursor.execute('select * from masterclass.users_part_day_platform;')
                result=cursor.fetchall()
                for i in result:
                    print(i)

        except Error as e:
            print("Error while connecting to MySQL", e)


def most_viewed_courses():
        try:
            conn=msql.connect(host='localhost',database='masterclass',user='root',password='infy@123')
            if conn.is_connected():
                cursor=conn.cursor()
                cursor.execute('''create temporary table if not exists temp AS (select timestamp
                                                                                        ,userid
                                                                                        ,platform
                                                                                        ,course_id
                                                                                        ,chapter_id
                                                                                        ,CASE 
                                                                                            WHEN HOUR(timestamp)>='00' AND HOUR(timestamp)<='12' THEN 'Morning'
                                                                                            WHEN HOUR(timestamp)>'12' AND HOUR(timestamp)<='17' THEN 'Afternoon'
                                                                                            WHEN HOUR(timestamp)>'17' AND HOUR(timestamp)<'24' THEN 'Evening'
                                                                                         END as part_day
        
                                                                                    from Data);'''
                               )
                print('temporary temp table created')
                cursor.execute('''CREATE TABLE IF NOT EXISTS masterclass.most_viewed_courses AS (select t.part_day,t.course_id,t.most_viewed_course from
                                                                                                    (select part_day,course_id,count(*) as most_viewed_course
                                                                                                        ,rank() OVER (partition by part_day order by count(*) desc) AS rn
                                                                                                    from temp
                                                                                                    group by part_day,course_id)t
                                                                                                    where rn=1);'''
                               )
                print('masterclass.most_viewed_courses table created')
                cursor.execute('select * from masterclass.most_viewed_courses;')
                result=cursor.fetchall()
                for i in result:
                    print(i)

        except Error as e:
            print("Error while connecting to MySQL", e)


def most_viewed_chapters():
        try:
            conn=msql.connect(host='localhost',database='masterclass',user='root',password='infy@123')
            if conn.is_connected():
                cursor=conn.cursor()
                cursor.execute('''create temporary table if not exists temp AS (select timestamp
                                                                                        ,userid
                                                                                        ,platform
                                                                                        ,course_id
                                                                                        ,chapter_id
                                                                                        ,CASE 
                                                                                            WHEN HOUR(timestamp)>='00' AND HOUR(timestamp)<='12' THEN 'Morning'
                                                                                            WHEN HOUR(timestamp)>'12' AND HOUR(timestamp)<='17' THEN 'Afternoon'
                                                                                            WHEN HOUR(timestamp)>'17' AND HOUR(timestamp)<'24' THEN 'Evening'
                                                                                         END as part_day
        
                                                                                    from Data);'''
                               )
                print('temporary temp table created')
                cursor.execute('''CREATE TABLE IF NOT EXISTS masterclass.most_viewed_chapters AS (select t.part_day,t.chapter_id,t.most_viewed_chapters from
                                                                                                    (select part_day,chapter_id,count(*) as most_viewed_chapters
                                                                                                        ,rank() OVER (partition by part_day order by count(*) desc) AS rn
                                                                                                    from temp
                                                                                                    group by part_day,chapter_id)t
                                                                                                    where rn=1);'''
                               )
                print('masterclass.most_viewed_chapters table created')
                cursor.execute('select * from masterclass.most_viewed_chapters;')
                result=cursor.fetchall()
                for i in result:
                    print(i)

        except Error as e:
            print("Error while connecting to MySQL", e)

def main():
    data=pd.read_csv('C:\\Users\\aayus\\Documents\\Masterclass\\Interview_exercise_Data_Engineering\\Interview_exercise_Data_Engineering\\data.csv'
                 ,index_col=False,delimiter=',')
    #print(data.head())
    #print(data.count())
    data=data.dropna(axis=0)
    #print(data.count())
    connect_to_mysql()
    import_csv_into_mysql(data)
    users_part_day_platform()
    most_viewed_courses()
    most_viewed_chapters()

if __name__ == "__main__":
    main()


