What is expected : 
 -- Develop Python code ( using your preferred libraries ) 
 -- Share the code via your GitHub repo , we will review during the onsite interview
 -- We expect the code executes on your system
 -- Using the project and code as base, We will discuss various scenarios relatedt to deployment of code in production.


Information on DATA in csv file:
data.csv - Small sample dataset : "timestamp","user_id","platform","course_id","chapter_id"


What should the  Python library should : 

1 :  A package/script should Load the data.csv in your local SQLite database ( or any other local DB if you have on your system e,g, Mysql or postgres )

2 :  A script should derive below metrics ( via SQL or other method ) and store in separate local tables in the same DB 

[ Note : Above should be done in core python code and not a ETL tool ] 

3   Create aggregate tables for below 
     
A]  Counts of users split by various parts of the day [ morning : 00 hrs to noon , afternoon : 12 hrs to 17hrs , evening : 17hrs to 24 hrs ]  & platform 
		     The table data should help to understand usage for various platforms in different parts of the days 

B]  Table which provides counts for most viewed courses  split by various parts of the day
C]  Table which provides counts for most viewed chapters  split by various parts of the day